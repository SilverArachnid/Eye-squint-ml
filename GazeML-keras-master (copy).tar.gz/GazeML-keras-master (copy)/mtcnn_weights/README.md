Weights files are form https://github.com/davidsandberg/facenet/tree/master/src/align
