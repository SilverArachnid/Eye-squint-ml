
import math
import numpy as np
import cv2
from matplotlib import pyplot as plt

fn="/home/susaat/Desktop/GazeML-keras-master/test_imgs/plain-white-background.jpg"
input_img = cv2.imread(fn)[..., ::-1]


draw2 = input_img.copy()
draw2 = cv2.resize(draw2, (180,108))[np.newaxis, ..., np.newaxis]
draw2 = cv2.cv2.circle(draw2, (100,100), 10, (255,255,0), -1) 
plt.imshow(draw2)
plt.show()

im_shape =input_img.shape[::-1]
draw3 = cv2.resize(draw2, im_shape[1:])



plt.title('Output image')
plt.imshow(draw3)
plt.show()
