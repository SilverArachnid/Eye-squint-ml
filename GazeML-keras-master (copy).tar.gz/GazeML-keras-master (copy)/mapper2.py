import os
os.environ["CUDA_VISIBLE_DEVICES"]="-1"

from detector.face_detector import MTCNNFaceDetector
from models.elg_keras import KerasELG
from keras import backend as K

import numpy as np
import cv2
from matplotlib import pyplot as plt

"""## Instantiate face detector

We apply MTCNN for face and 5-points landmarks detection.
"""



"""## Instantiate GazeML ELG model

A stacked hourglass framework for iris and eye-lid detection.
"""

model = KerasELG()
model.net.load_weights("/home/susaat/Desktop/GazeML-keras-master/elg_weights/elg_keras.h5")

"""## Load image"""

fnr = "/home/susaat/Pictures/Webcam/2019-07-10-121556.jpg"
right_eye_im = cv2.imread(fnr)[..., ::-1]
dim_x1=right_eye_im.shape[1]
dim_y1=right_eye_im.shape[0]

fnl = "/home/susaat/Pictures/Webcam/2019-07-10-121557.jpg"
left_eye_im = cv2.imread(fnl)[..., ::-1]
dim_x2=left_eye_im.shape[1]
dim_y2=left_eye_im.shape[0]


pupil_center_right_cp=right_eye_im.copy()
pupil_center_left_cp=left_eye_im.copy()



plt.subplot(1,2,1)
plt.title('Input image rt')
plt.imshow(right_eye_im)
plt.subplot(1,2,2)
plt.title('Input image lf')
plt.imshow(left_eye_im)
plt.show()

inp_left = cv2.cvtColor(left_eye_im, cv2.COLOR_RGB2GRAY)
inp_left = cv2.equalizeHist(inp_left)
inp_left = cv2.resize(inp_left, (180,108))[np.newaxis, ..., np.newaxis]

inp_right = cv2.cvtColor(right_eye_im, cv2.COLOR_RGB2GRAY)
inp_right = cv2.equalizeHist(inp_right)
inp_right = cv2.resize(inp_right, (180,108))[np.newaxis, ..., np.newaxis]

plt.figure(figsize=(8,3))
plt.subplot(1,2,1)
plt.title('right eye')
plt.imshow(inp_left[0,...,0], cmap="gray")
plt.subplot(1,2,2)
plt.title('Right eye')
plt.imshow(inp_right[0,...,0], cmap="gray")
plt.show()

"""## Predict eye region landmarks

ELG forwardpass. Output shape: (36, 60, 18)
"""

inp_left.shape, inp_right.shape

input_array = np.concatenate([inp_left, inp_right], axis=0)
pred_left, pred_right = model.net.predict(input_array/255 * 2 - 1)

"""## Visualize output heatmaps

Eighteen heatmaps are predicted: 
- Eight heatmaps for iris (green)
- Eight heatmaps for eye-lid (red)
- Two heatmaps for pupil (blue)
"""

#@title
plt.figure(figsize=(10,4))
plt.subplot(1,2,1)
plt.axis('off')
plt.title('Right eye heatmaps left')
hm_r = np.max(pred_left[...,:8], axis=-1, keepdims=True)
hm_g = np.max(pred_left[...,8:16], axis=-1, keepdims=True)
hm_b = np.max(pred_left[...,16:], axis=-1, keepdims=True)
plt.imshow(np.concatenate([hm_r, hm_g, hm_b], axis=-1))
plt.subplot(1,2,2)
plt.axis('off')
plt.title('Right eye heatmaps center')
hm_r = np.max(pred_right[...,:8], axis=-1, keepdims=True)
hm_g = np.max(pred_right[...,8:16], axis=-1, keepdims=True)
hm_b = np.max(pred_right[...,16:], axis=-1, keepdims=True)
plt.imshow(np.concatenate([hm_r, hm_g, hm_b], axis=-1))
plt.show()

"""# Draw eye region landmarks"""

def draw_pupil(im, inp_im, lms):
    draw = im.copy()
    draw = cv2.resize(draw, (inp_im.shape[2], inp_im.shape[1]))
    pupil_center = np.zeros((2,))
    pnts_outerline = []
    pnts_innerline = []
    stroke = inp_im.shape[1] // 12 + 1
    
    for i, lm in enumerate(np.squeeze(lms)):
        y, x = int(lm[0]*3), int(lm[1]*3)

        if i < 8:
            pnts_outerline.append([y, x])
        elif i < 16:
            pnts_innerline.append([y, x])
            pupil_center += (y,x)
    
    pupil_center = (pupil_center/8).astype(np.int32)
    draw = cv2.cv2.circle(draw, (pupil_center[0], pupil_center[1]), 1, (255,255,0), -1)        
    draw = cv2.polylines(draw, [np.array(pnts_outerline).reshape(-1,1,2)], isClosed=True, color=(125,255,125), thickness=stroke//4)
    draw = cv2.polylines(draw, [np.array(pnts_innerline).reshape(-1,1,2)], isClosed=True, color=(125,125,255), thickness=stroke//4)
    return draw, pupil_center

plt.figure(figsize=(15,4))
plt.subplot(1,2,1)
plt.title("Right eye left")
lms_left = model._calculate_landmarks(pred_left)
result_left, pupil_center_left = draw_pupil(left_eye_im, inp_left, lms_left)
plt.imshow(result_left)
print(pupil_center_left)

plt.subplot(1,2,2)
plt.title("Right eye center")
lms_right = model._calculate_landmarks(pred_right)
result_right, pupil_center_right = draw_pupil(right_eye_im, inp_right, lms_right)
plt.imshow(result_right)
plt.show()

print(pupil_center_right)

plt.figure(figsize=(15,4))
plt.subplot(1,2,1)
ratio_x1=dim_x2/180
ratio_y1=dim_y2/108
print(ratio_x1)
print(pupil_center_left[0])
pupil_center_left[0]=int((pupil_center_left[0])*(ratio_x1))

pupil_center_left[1]=int(pupil_center_left[1]*ratio_y1)
pupil_center_left_cp = cv2.cv2.circle(pupil_center_left_cp, (pupil_center_left[0], pupil_center_left[1]), 10, (255,255,0), -1)
print(pupil_center_left)
plt.imshow(pupil_center_left_cp)


plt.subplot(1,2,2)
ratio_x2=dim_x1/180
ratio_y2=dim_y1/108
pupil_center_right[0]=int(pupil_center_right[0]*ratio_x2)
pupil_center_right[1]=int(pupil_center_right[1]*ratio_y2)
pupil_center_right_cp = cv2.cv2.circle(pupil_center_right_cp, (pupil_center_right[0], pupil_center_right[1]), 10, (255,255,0), -1)
print(pupil_center_right)
plt.imshow(pupil_center_right_cp)
plt.show()

dist_bet_centre = np.linalg.norm(pupil_center_left - pupil_center_right)
print("distance in pixels is :")
ans=str(round(dist_bet_centre,2))
print(ans)

ac_dist=dist_bet_centre*(50/1280)
print("distance in mm is :")
answer=str(round(ac_dist,2))
print(answer)
	
cv2.waitKey(10000)
cv2.destroyAllWindows()
