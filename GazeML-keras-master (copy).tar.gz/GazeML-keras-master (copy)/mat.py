import matplotlib.pyplot as plt

data = [[0, 0.25], [0.5, 0.75]]

fig, ax = plt.subplots()
im = ax.imshow(data, cmap=plt.get_cmap('hot'), interpolation='nearest',
               vmin=0, vmax=1)
fig.colorbar(im)
plt.show()


hl=int(left_eye_xy[0]+eye_bbox_h//2)-int(left_eye_xy[0]-eye_bbox_h//2)
hl=hl/2

wl=int(left_eye_xy[1]+eye_bbox_w//2)-int(left_eye_xy[1]-eye_bbox_w//2)
wl=wl/2

hr=int(right_eye_xy[0]+eye_bbox_h//2)- int(right_eye_xy[0]-eye_bbox_h//2)
hr=hr/2

wr=int(right_eye_xy[1]+eye_bbox_w//2)-int(right_eye_xy[1]-eye_bbox_w//2)
wr=wr/2

adyl=left_eye_xy[0]-hl
adxl=left_eye_xy[1]-wl

adyr=right_eye_xy[0]-hr
adxr=right_eye_xy[1]-wr